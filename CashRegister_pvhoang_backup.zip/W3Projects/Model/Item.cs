﻿using System;
namespace W3Projects
{
    public class Item
    {
        public string name { get; set; }
        public int quantity { get; set; }
        public int price { get; set; }

        public Item() { }
        public Item(string name, int price, int quantity)
        {
            this.name = name;
            this.quantity = quantity;
            this.price = price;
        }
        
    }
}
