﻿using System;
using System.Collections.Generic;
using System.Windows.Input;
using Xamarin.Forms;

namespace W3Projects
{
    public partial class GridPage : ContentPage
    {
        public GridPage(GridPage gridPage)
        {
            InitializeComponent();
        }
        //create no argument
        public GridPage()
        {
            InitializeComponent();
        }

    }
}
